--
-- Base de datos: `spring`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `nombre` varchar(256) NOT NULL,
  `descripcion` mediumtext NOT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `items`
--

INSERT INTO `items` (`id`, `nombre`, `descripcion`, `url`) VALUES
(1, 'Assassin''s Creed', 'Assassin''s Creed es un galardonado videojuego de ficción histórica en tercera persona, de sigilo, acción, aventura y mundo abierto desarrollado por Ubisoft Montreal. La mayor parte del juego tiene lugar durante la Tercera Cruzada en Tierra Santa.', 'http://www.mejorenvo.com/uploads/imagenes/assasins_creed_lineage.jpg'),
(2, 'Ni-oh', 'Nioh is an action role-playing game set in Japan during the year 1600, with players taking the role of an Irish samurai named William.[4] The player guides William on missions through enclosed environments fighting both human enemies and supernatural beings called yokai.', 'http://publica.videooca.com/77252-large_default/ni-oh-ps4.jpg'),
(3, 'Shadow of the Colossus', 'El juego trata de un joven conocido únicamente como Wander (del inglés wanderer, (‘alguien que deambula’), que debe viajar a caballo a través de un vasto territorio y derrotar a 16 gigantes.', 'http://www.queflan.com/wp-content/uploads/2017/01/portada-YOUTUBE-shadow-of-the-colossus.jpg'),
(4, 'Uncharted 4', 'Cronológicamente el juego toma lugar cuatro años después de Uncharted 3: La traición de Drake. El retirado cazafortunas Nathan Drake vive felizmente su vida junto con su esposa Elena Fisher, pero todo se derrumba cuando aparece su hermano Sam, a quien Nathan daba por muerto.', 'https://upload.wikimedia.org/wikipedia/en/1/1a/Uncharted_4_box_artwork.jpg');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
